
import pandas as pd
import numpy as np
import os

from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# --------------------------------------------------
# 1. LOAD PROCESSED DATA
# --------------------------------------------------

X_train = pd.read_csv("processed_data/X_train.csv")
X_test = pd.read_csv("processed_data/X_test.csv")

y_train = pd.read_csv("processed_data/y_reg_train.csv").squeeze()
y_test = pd.read_csv("processed_data/y_reg_test.csv").squeeze()

os.makedirs("regression_results", exist_ok=True)

# --------------------------------------------------
# 2. CREATE TWO FEATURE SETS
# --------------------------------------------------

# Experiment A: All 45 features
feature_sets = {
    "All_Features": (X_train, X_test)
}

# Experiment B: Remove potentially suspicious features
suspicious_features = [
    "numeric__Travel Time Index",
    "numeric__Road Capacity Utilization"
]

X_train_reduced = X_train.drop(
    columns=suspicious_features,
    errors="ignore"
)

X_test_reduced = X_test.drop(
    columns=suspicious_features,
    errors="ignore"
)

feature_sets["Without_Suspicious_Features"] = (
    X_train_reduced,
    X_test_reduced
)

# --------------------------------------------------
# 3. DEFINE REGRESSION MODELS
# --------------------------------------------------

models = {
    "Mean Baseline": DummyRegressor(strategy="mean"),

    "Linear Regression": LinearRegression(),

    "Polynomial + Ridge": Pipeline([
        ("polynomial", PolynomialFeatures(
            degree=2,
            include_bias=False
        )),
        ("ridge", Ridge(alpha=1.0))
    ]),

    "Decision Tree": DecisionTreeRegressor(
        max_depth=12,
        random_state=42
    ),

    "KNN": KNeighborsRegressor(
        n_neighbors=5
    ),

    "MLP": MLPRegressor(
        hidden_layer_sizes=(100, 50),
        activation="relu",
        max_iter=1000,
        early_stopping=True,
        random_state=42
    )
}

# --------------------------------------------------
# 4. TRAIN AND EVALUATE MODELS
# --------------------------------------------------

all_results = []
all_predictions = {}

for feature_set_name, (Xtr, Xte) in feature_sets.items():

    print("\n====================================")
    print("FEATURE SET:", feature_set_name)
    print("====================================")

    for model_name, model in models.items():

        print("\nTraining:", model_name)

        # Train model
        model.fit(Xtr, y_train)

        # Predict on test data
        predictions = model.predict(Xte)

        # Calculate metrics
        rmse = np.sqrt(mean_squared_error(y_test, predictions))
        mae = mean_absolute_error(y_test, predictions)
        r2 = r2_score(y_test, predictions)

        print("RMSE:", round(rmse, 4))
        print("MAE:", round(mae, 4))
        print("R2 Score:", round(r2, 4))

        # Store results
        all_results.append({
            "Feature Set": feature_set_name,
            "Model": model_name,
            "RMSE": rmse,
            "MAE": mae,
            "R2": r2
        })

        # Store predictions
        all_predictions[
            f"{feature_set_name}_{model_name}"
        ] = predictions

# --------------------------------------------------
# 5. SAVE RESULTS
# --------------------------------------------------

results_df = pd.DataFrame(all_results)

results_df.to_csv(
    "regression_results/regression_metrics.csv",
    index=False
)

predictions_df = pd.DataFrame({
    "Actual Congestion": y_test.reset_index(drop=True)
})

for name, predictions in all_predictions.items():
    predictions_df[name] = predictions

predictions_df.to_csv(
    "regression_results/regression_predictions.csv",
    index=False
)

# --------------------------------------------------
# 6. DISPLAY MODEL COMPARISON
# --------------------------------------------------

print("\n\nFINAL REGRESSION COMPARISON")
print(results_df.sort_values(
    by=["Feature Set", "RMSE"]
).to_string(index=False))

print("\nRegression experiments completed successfully!")
print("Check the regression_results folder.")
