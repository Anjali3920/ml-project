
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ------------------------------------------
# 1. LOAD RESULTS
# ------------------------------------------

reg = pd.read_csv(
    "regression_results/regression_metrics.csv"
)

cls = pd.read_csv(
    "classification_results/classification_metrics.csv"
)

os.makedirs("evaluation_graphs", exist_ok=True)

sns.set_theme(style="whitegrid")

# ------------------------------------------
# 2. REGRESSION METRIC COMPARISONS
# ------------------------------------------

regression_metrics = ["RMSE", "MAE", "R2"]

for metric in regression_metrics:

    plt.figure(figsize=(13, 6))

    sns.barplot(
        data=reg,
        x="Model",
        y=metric,
        hue="Feature Set"
    )

    plt.title(f"Regression Model Comparison - {metric}")
    plt.xticks(rotation=30)
    plt.tight_layout()

    plt.savefig(
        f"evaluation_graphs/regression_{metric}.png"
    )
    plt.close()

# ------------------------------------------
# 3. CLASSIFICATION COMPARISONS
# ------------------------------------------

classification_metrics = [
    "Accuracy",
    "Macro Precision",
    "Macro Recall",
    "Macro F1"
]

for metric in classification_metrics:

    plt.figure(figsize=(13, 6))

    sns.barplot(
        data=cls,
        x="Model",
        y=metric,
        hue="Feature Set"
    )

    plt.title(f"Classification Model Comparison - {metric}")
    plt.xticks(rotation=30)
    plt.tight_layout()

    plt.savefig(
        f"evaluation_graphs/classification_{metric.replace(' ', '_')}.png"
    )
    plt.close()

# ------------------------------------------
# 4. CONFUSION MATRIX HEATMAPS
# ------------------------------------------

for filename in os.listdir("classification_results"):

    if filename.endswith("_confusion_matrix.csv"):

        cm = pd.read_csv(
            os.path.join("classification_results", filename),
            index_col=0
        )

        plt.figure(figsize=(6, 5))

        sns.heatmap(
            cm,
            annot=True,
            fmt="g",
            cmap="Blues"
        )

        plt.title(filename.replace("_", " "))
        plt.xlabel("Predicted Category")
        plt.ylabel("Actual Category")
        plt.tight_layout()

        output_name = filename.replace(".csv", ".png")

        plt.savefig(
            f"evaluation_graphs/{output_name}"
        )
        plt.close()

# ------------------------------------------
# 5. ACTUAL VS PREDICTED REGRESSION
# ------------------------------------------

predictions = pd.read_csv(
    "regression_results/regression_predictions.csv"
)

actual = predictions["Actual Congestion"]

# Plot every model using all features
all_feature_columns = [
    col for col in predictions.columns
    if col.startswith("All_Features_")
]

for column in all_feature_columns:

    plt.figure(figsize=(7, 6))

    plt.scatter(
        actual,
        predictions[column],
        alpha=0.4
    )

    plt.plot(
        [0, 100],
        [0, 100],
        linestyle="--"
    )

    plt.xlabel("Actual Congestion")
    plt.ylabel("Predicted Congestion")
    plt.title(column.replace("_", " "))

    plt.tight_layout()

    plt.savefig(
        f"evaluation_graphs/{column}_actual_vs_predicted.png"
    )
    plt.close()

# ------------------------------------------
# 6. RESIDUAL PLOTS
# ------------------------------------------

for column in all_feature_columns:

    residuals = actual - predictions[column]

    plt.figure(figsize=(8, 5))

    plt.scatter(
        predictions[column],
        residuals,
        alpha=0.4
    )

    plt.axhline(y=0, linestyle="--")

    plt.xlabel("Predicted Congestion")
    plt.ylabel("Residual Error")
    plt.title(column.replace("_", " ") + " Residual Plot")

    plt.tight_layout()

    plt.savefig(
        f"evaluation_graphs/{column}_residuals.png"
    )
    plt.close()

# ------------------------------------------
# 7. PRINT COMPARISON TABLES
# ------------------------------------------

print("\nREGRESSION RESULTS")
print(reg.sort_values("RMSE").to_string(index=False))

print("\nCLASSIFICATION RESULTS")
print(
    cls.sort_values(
        "Macro F1",
        ascending=False
    ).to_string(index=False)
)

print("\nAll evaluation graphs generated successfully!")
