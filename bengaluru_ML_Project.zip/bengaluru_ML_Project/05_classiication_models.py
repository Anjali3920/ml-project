
import pandas as pd
import numpy as np
import os

from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix
)

# --------------------------------------------------
# 1. LOAD PROCESSED DATA
# --------------------------------------------------

X_train = pd.read_csv("processed_data/X_train.csv")
X_test = pd.read_csv("processed_data/X_test.csv")

y_train = pd.read_csv(
    "processed_data/y_cls_train.csv"
).squeeze()

y_test = pd.read_csv(
    "processed_data/y_cls_test.csv"
).squeeze()

os.makedirs("classification_results", exist_ok=True)

# --------------------------------------------------
# 2. FEATURE SETS
# --------------------------------------------------

feature_sets = {
    "All_Features": (X_train, X_test)
}

suspicious_features = [
    "numeric__Travel Time Index",
    "numeric__Road Capacity Utilization"
]

X_train_reduced = X_train.drop(
    columns=suspicious_features,
    errors="ignore"
)

X_test_reduced = X_test.drop(
    columns=suspicious_features,
    errors="ignore"
)

feature_sets["Without_Suspicious_Features"] = (
    X_train_reduced,
    X_test_reduced
)

# --------------------------------------------------
# 3. DEFINE CLASSIFICATION MODELS
# --------------------------------------------------

models = {
    "Majority Baseline": DummyClassifier(
        strategy="most_frequent"
    ),

    "Logistic Regression": LogisticRegression(
        max_iter=2000,
        class_weight="balanced",
        random_state=42
    ),

    "Decision Tree": DecisionTreeClassifier(
        max_depth=12,
        class_weight="balanced",
        random_state=42
    ),

    "KNN": KNeighborsClassifier(
        n_neighbors=5
    ),

    "MLP": MLPClassifier(
        hidden_layer_sizes=(100, 50),
        activation="relu",
        max_iter=1000,
        early_stopping=True,
        random_state=42
    )
}

# --------------------------------------------------
# 4. TRAIN AND EVALUATE
# --------------------------------------------------

all_results = []
all_predictions = {}

labels = ["Low", "Moderate", "High"]

for feature_set_name, (Xtr, Xte) in feature_sets.items():

    print("\n====================================")
    print("FEATURE SET:", feature_set_name)
    print("====================================")

    for model_name, model in models.items():

        print("\nTraining:", model_name)

        model.fit(Xtr, y_train)

        predictions = model.predict(Xte)

        accuracy = accuracy_score(y_test, predictions)

        precision = precision_score(
            y_test, predictions,
            average="macro",
            zero_division=0
        )

        recall = recall_score(
            y_test, predictions,
            average="macro",
            zero_division=0
        )

        f1 = f1_score(
            y_test, predictions,
            average="macro",
            zero_division=0
        )

        print("Accuracy:", round(accuracy, 4))
        print("Macro Precision:", round(precision, 4))
        print("Macro Recall:", round(recall, 4))
        print("Macro F1:", round(f1, 4))

        print("\nClassification Report:")
        print(classification_report(
            y_test,
            predictions,
            labels=labels,
            zero_division=0
        ))

        cm = confusion_matrix(
            y_test,
            predictions,
            labels=labels
        )

        print("Confusion Matrix:")
        print(cm)

        all_results.append({
            "Feature Set": feature_set_name,
            "Model": model_name,
            "Accuracy": accuracy,
            "Macro Precision": precision,
            "Macro Recall": recall,
            "Macro F1": f1
        })

        all_predictions[
            f"{feature_set_name}_{model_name}"
        ] = predictions

        # Save individual confusion matrix
        cm_df = pd.DataFrame(
            cm,
            index=labels,
            columns=labels
        )

        safe_name = model_name.replace(" ", "_")

        cm_df.to_csv(
            f"classification_results/"
            f"{feature_set_name}_{safe_name}_confusion_matrix.csv"
        )

# --------------------------------------------------
# 5. SAVE RESULTS
# --------------------------------------------------

results_df = pd.DataFrame(all_results)

results_df.to_csv(
    "classification_results/classification_metrics.csv",
    index=False
)

predictions_df = pd.DataFrame({
    "Actual Category": y_test.reset_index(drop=True)
})

for name, predictions in all_predictions.items():
    predictions_df[name] = predictions

predictions_df.to_csv(
    "classification_results/classification_predictions.csv",
    index=False
)

# --------------------------------------------------
# 6. FINAL COMPARISON
# --------------------------------------------------

print("\n\nFINAL CLASSIFICATION COMPARISON")

print(
    results_df.sort_values(
        by=["Feature Set", "Macro F1"],
        ascending=[True, False]
    ).to_string(index=False)
)

print("\nClassification experiments completed successfully!")
print("Check the classification_results folder.")
