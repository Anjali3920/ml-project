
import pandas as pd
import numpy as np
import os

print("=" * 55)
print("BENGALURU TRAFFIC PREDICTION - FINAL PROJECT AUDIT")
print("=" * 55)

# 1. Load regression and classification results
reg = pd.read_csv(
    "regression_results/regression_metrics.csv"
)

cls = pd.read_csv(
    "classification_results/classification_metrics.csv"
)

# 2. Check expected experiment counts
print("\n1. EXPERIMENT COUNTS")

print("Regression experiments:", len(reg))
print("Classification experiments:", len(cls))

print("Expected regression experiments: 12")
print("Expected classification experiments: 10")

# 3. Check missing metric values
print("\n2. MISSING METRIC VALUES")

print("Regression missing values:")
print(reg.isnull().sum())

print("\nClassification missing values:")
print(cls.isnull().sum())

# 4. Check infinite values
print("\n3. INFINITE METRIC VALUES")

print("Regression infinite values:")
print(np.isinf(reg.select_dtypes(include="number")).sum())

print("\nClassification infinite values:")
print(np.isinf(cls.select_dtypes(include="number")).sum())

# 5. Best regression models
print("\n4. BEST REGRESSION RESULTS")

for feature_set in reg["Feature Set"].unique():

    subset = reg[reg["Feature Set"] == feature_set]

    print("\nFeature Set:", feature_set)

    print(
        subset.sort_values("RMSE")[
            ["Model", "RMSE", "MAE", "R2"]
        ].to_string(index=False)
    )

# 6. Best classification models
print("\n5. BEST CLASSIFICATION RESULTS")

for feature_set in cls["Feature Set"].unique():

    subset = cls[cls["Feature Set"] == feature_set]

    print("\nFeature Set:", feature_set)

    print(
        subset.sort_values(
            "Macro F1",
            ascending=False
        )[
            ["Model", "Accuracy", "Macro Precision",
             "Macro Recall", "Macro F1"]
        ].to_string(index=False)
    )

# 7. Check test class distribution
print("\n6. TEST CLASS DISTRIBUTION")

y_test = pd.read_csv(
    "processed_data/y_cls_test.csv"
).squeeze()

print(y_test.value_counts())
print("\nTest class percentages:")
print(y_test.value_counts(normalize=True) * 100)

# 8. Check saved predictions
print("\n7. PREDICTION FILE CHECK")

reg_predictions = pd.read_csv(
    "regression_results/regression_predictions.csv"
)

cls_predictions = pd.read_csv(
    "classification_results/classification_predictions.csv"
)

print("Regression prediction rows:", len(reg_predictions))
print("Classification prediction rows:", len(cls_predictions))

# 9. Check output folders
print("\n8. OUTPUT FILE COUNTS")

for folder in [
    "eda_graphs",
    "processed_data",
    "regression_results",
    "classification_results",
    "evaluation_graphs"
]:
    if os.path.exists(folder):
        print(folder, ":", len(os.listdir(folder)), "files")
    else:
        print(folder, ": MISSING")

print("\n" + "=" * 55)
print("FINAL AUDIT COMPLETED")
print("=" * 55)
