
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load dataset
df = pd.read_csv("Banglore_traffic_Dataset.csv")

# Convert Date into datetime format
df["Date"] = pd.to_datetime(df["Date"])

# Create output folder
os.makedirs("eda_graphs", exist_ok=True)

sns.set_theme(style="whitegrid")

# 1. Congestion distribution
plt.figure(figsize=(9, 5))
sns.histplot(data=df, x="Congestion Level", bins=20, kde=True)
plt.title("Distribution of Congestion Level")
plt.savefig("eda_graphs/01_congestion_distribution.png")
plt.close()

# 2. Average congestion by area
plt.figure(figsize=(11, 5))
sns.barplot(data=df, x="Area Name", y="Congestion Level")
plt.xticks(rotation=45)
plt.title("Average Congestion by Area")
plt.tight_layout()
plt.savefig("eda_graphs/02_congestion_by_area.png")
plt.close()

# 3. Average congestion by road
plt.figure(figsize=(13, 6))
sns.barplot(data=df, x="Road/Intersection Name", y="Congestion Level")
plt.xticks(rotation=90)
plt.title("Average Congestion by Road")
plt.tight_layout()
plt.savefig("eda_graphs/03_congestion_by_road.png")
plt.close()

# 4. Traffic volume distribution
plt.figure(figsize=(9, 5))
sns.histplot(data=df, x="Traffic Volume", bins=30, kde=True)
plt.title("Traffic Volume Distribution")
plt.savefig("eda_graphs/04_traffic_volume.png")
plt.close()

# 5. Average speed distribution
plt.figure(figsize=(9, 5))
sns.histplot(data=df, x="Average Speed", bins=30, kde=True)
plt.title("Average Speed Distribution")
plt.savefig("eda_graphs/05_average_speed.png")
plt.close()

# 6. Boxplots of numerical features
numeric_columns = df.select_dtypes(include="number").columns

for column in numeric_columns:
    plt.figure(figsize=(8, 4))
    sns.boxplot(data=df, x=column)
    plt.title(f"Boxplot of {column}")
    plt.tight_layout()
    plt.savefig(f"eda_graphs/boxplot_{column.replace(' ', '_')}.png")
    plt.close()

# 7. Traffic volume vs congestion
plt.figure(figsize=(9, 5))
sns.scatterplot(data=df, x="Traffic Volume", y="Congestion Level", alpha=0.5)
plt.title("Traffic Volume vs Congestion")
plt.savefig("eda_graphs/07_volume_vs_congestion.png")
plt.close()

# 8. Average speed vs congestion
plt.figure(figsize=(9, 5))
sns.scatterplot(data=df, x="Average Speed", y="Congestion Level", alpha=0.5)
plt.title("Average Speed vs Congestion")
plt.savefig("eda_graphs/08_speed_vs_congestion.png")
plt.close()

# 9. Weather vs congestion
plt.figure(figsize=(9, 5))
sns.boxplot(data=df, x="Weather Conditions", y="Congestion Level")
plt.xticks(rotation=30)
plt.title("Weather vs Congestion")
plt.tight_layout()
plt.savefig("eda_graphs/09_weather_vs_congestion.png")
plt.close()

# 10. Roadwork vs congestion
plt.figure(figsize=(9, 5))
sns.boxplot(data=df, x="Roadwork and Construction Activity",
            y="Congestion Level")
plt.title("Roadwork vs Congestion")
plt.tight_layout()
plt.savefig("eda_graphs/10_roadwork_vs_congestion.png")
plt.close()

# 11. Correlation heatmap
numeric_df = df.select_dtypes(include="number")
correlation_matrix = numeric_df.corr()

plt.figure(figsize=(14, 10))
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("eda_graphs/11_correlation_heatmap.png")
plt.close()

# 12. Monthly congestion trend
monthly_congestion = (
    df.set_index("Date")["Congestion Level"]
      .resample("ME")
      .mean()
)

plt.figure(figsize=(12, 5))
monthly_congestion.plot(marker="o")
plt.title("Monthly Average Congestion Trend")
plt.xlabel("Month")
plt.ylabel("Average Congestion")
plt.tight_layout()
plt.savefig("eda_graphs/12_monthly_congestion.png")
plt.close()

print("All EDA visualizations generated successfully!")
print("Check the eda_graphs folder.")

