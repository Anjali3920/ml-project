
import pandas as pd

# 1. Load the complete dataset
df = pd.read_csv("Banglore_traffic_Dataset.csv")

# 2. Display first five rows
print("\nFIRST FIVE ROWS")
print(df.head())

# 3. Dataset dimensions
print("\nDATASET SHAPE")
print(df.shape)

# 4. All column names
print("\nALL COLUMNS")
print(df.columns.tolist())

# 5. Data types and non-null counts
print("\nDATASET INFORMATION")
df.info()

# 6. Statistical summary of numerical columns
print("\nNUMERICAL SUMMARY")
print(df.describe())

# 7. Statistical summary of all columns
print("\nCOMPLETE SUMMARY")
print(df.describe(include="all"))

# 8. Missing values
print("\nMISSING VALUES")
print(df.isnull().sum())

# 9. Total duplicate rows
print("\nDUPLICATE ROWS")
print(df.duplicated().sum())

# 10. Unique values in every column
print("\nUNIQUE VALUES")
print(df.nunique())

# 11. Unique categories in categorical columns
categorical_columns = df.select_dtypes(include="object").columns

for column in categorical_columns:
    print(f"\n{column}")
    print(df[column].value_counts())
