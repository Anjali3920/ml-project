
import pandas as pd
import numpy as np
import os

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

# 1. Load dataset
df = pd.read_csv("Banglore_traffic_Dataset.csv")

# 2. Convert Date
df["Date"] = pd.to_datetime(df["Date"])

# 3. Extract date features
df["Year"] = df["Date"].dt.year
df["Month"] = df["Date"].dt.month
df["Day"] = df["Date"].dt.day
df["DayOfWeek"] = df["Date"].dt.dayofweek

# 4. Create classification target
df["Congestion Category"] = pd.cut(
    df["Congestion Level"],
    bins=[-np.inf, 30, 60, np.inf],
    labels=["Low", "Moderate", "High"],
    right=False
)

# 5. Define target columns
regression_target = "Congestion Level"
classification_target = "Congestion Category"

# 6. Remove original date and targets from input features
excluded_columns = [
    "Date",
    regression_target,
    classification_target
]

X = df.drop(columns=excluded_columns)

y_regression = df[regression_target]
y_classification = df[classification_target]

# 7. Chronological train-test split
df_sorted = df.sort_values("Date").reset_index(drop=True)

split_date = pd.Timestamp("2024-02-01")

train_df = df_sorted[df_sorted["Date"] < split_date]
test_df = df_sorted[df_sorted["Date"] >= split_date]

X_train = train_df.drop(columns=excluded_columns)
X_test = test_df.drop(columns=excluded_columns)

y_reg_train = train_df[regression_target]
y_reg_test = test_df[regression_target]

y_cls_train = train_df[classification_target]
y_cls_test = test_df[classification_target]

# 8. Identify categorical and numerical columns
categorical_columns = X_train.select_dtypes(
    include=["object", "category"]
).columns.tolist()

numerical_columns = X_train.select_dtypes(
    include=np.number
).columns.tolist()

# 9. Preprocessing pipelines
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("numeric", numeric_pipeline, numerical_columns),
    ("categorical", categorical_pipeline, categorical_columns)
])

# 10. Fit only on training data
X_train_processed = preprocessor.fit_transform(X_train)
X_test_processed = preprocessor.transform(X_test)

# 11. Create output directory
os.makedirs("processed_data", exist_ok=True)

# 12. Save processed datasets
from scipy.sparse import issparse

if issparse(X_train_processed):
    X_train_processed = X_train_processed.toarray()

if issparse(X_test_processed):
    X_test_processed = X_test_processed.toarray()

feature_names = preprocessor.get_feature_names_out()

X_train_final = pd.DataFrame(
    X_train_processed,
    columns=feature_names
)

X_test_final = pd.DataFrame(
    X_test_processed,
    columns=feature_names
)

X_train_final.to_csv("processed_data/X_train.csv", index=False)
X_test_final.to_csv("processed_data/X_test.csv", index=False)

y_reg_train.to_csv("processed_data/y_reg_train.csv", index=False)
y_reg_test.to_csv("processed_data/y_reg_test.csv", index=False)

y_cls_train.to_csv("processed_data/y_cls_train.csv", index=False)
y_cls_test.to_csv("processed_data/y_cls_test.csv", index=False)

# 13. Print summary
print("PREPROCESSING COMPLETED")
print("Training rows:", len(X_train_final))
print("Testing rows:", len(X_test_final))
print("Original features:", X.shape[1])
print("Processed features:", X_train_final.shape[1])
print("Categorical columns:", categorical_columns)
print("Numerical columns:", numerical_columns)
print("Training date range:", train_df["Date"].min(), "to", train_df["Date"].max())
print("Testing date range:", test_df["Date"].min(), "to", test_df["Date"].max())
print("Saved all processed datasets successfully.")
